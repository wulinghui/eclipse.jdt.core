package java.lang;

public class CloneNotSupportedException extends Exception {
}
